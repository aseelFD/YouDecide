{\rtf1\ansi\ansicpg1252\cocoartf1671\cocoasubrtf200
{\fonttbl\f0\fswiss\fcharset0 Helvetica;\f1\fnil\fcharset0 Menlo-Italic;\f2\fnil\fcharset0 Menlo-Regular;
\f3\fnil\fcharset0 Menlo-Bold;}
{\colortbl;\red255\green255\blue255;\red31\green31\blue36;\red108\green121\blue134;\red255\green255\blue255;
\red150\green134\blue245;\red252\green95\blue163;}
{\*\expandedcolortbl;;\csgenericrgb\c12054\c12284\c14131;\csgenericrgb\c42394\c47462\c52518;\csgenericrgb\c100000\c100000\c100000;
\csgenericrgb\c58752\c52717\c95948;\csgenericrgb\c98839\c37355\c63833;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 # Project \'91You Decide\'92 Description\
Compatible for Xcode 9.3 and above\
It allows user to login/signup to udacity, then can view a map for all over the world and can press and hold on any city to view a collection of flicker images. And finally the user can delete or refresh any images collection.\
\
\
\
# Installation\
First you have to install the podfile with terminal/command line\
In order to use it you will need to create a `Podfile` if you do not already have one. Information on installing cocoapods and creating a Podfile can be found at [Cocoapods.org](http://cocoapods.org/). (Hint \'97 to install cocoapods, run `sudo gem install cocoapods` from the command line; to create a Podfile, run `pod init`).\
\
Open up the Podfile and add the following dependency:\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0
\cf0 \cb2 \
\pard\tx593\pardeftab593\pardirnatural\partightenfactor0

\f1\i \cf3 # platform :ios, '9.0'
\f0\i0 \cf0 \
\

\f2 \cf4 target \cf5 'virtualTourist'\cf4  
\f3\b \cf6 do
\f0\b0 \cf0 \

\f2 \cf4     pod \cf5 'Alamofire'
\f0 \cf0 \

\f2 \cf4     pod \cf5 'Kingfisher'
\f0 \cf0 \

\f2 \cf4     
\f0 \cf0 \

\f3\b \cf6 end
\f0\b0 \cf0 \
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0
\cf0 \cb1 \
Save your Podfile and run 'pod install' from the command line.\
\
\
# Run the App\
Finally, now you open the \'91virtualTourist\'92 workspace then press run and have fun :)\
\
\
\
\
}