//
//  Router.swift
//  OnTheMap
//
//  Created by MAC on 17/05/1440 AH.
//  Copyright © 1440 MAC. All rights reserved.
//

import Foundation

struct Router {
    private init() {}
}
