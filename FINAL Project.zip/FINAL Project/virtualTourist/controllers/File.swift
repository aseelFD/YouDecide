//
//  File.swift
//  virtualTourist
//
//  Created by Mac on 17/06/1440 AH.
//  Copyright © 1440 tam. All rights reserved.
//

import Foundation
