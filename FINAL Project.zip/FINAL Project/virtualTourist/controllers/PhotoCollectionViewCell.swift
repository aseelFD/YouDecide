//
//  PhotoCollectionViewCell.swift
//  virtualTourist
//
//  Created by MAC on 14/06/1440 AH.
//  Copyright © 1440 MAC. All rights reserved.
//

import Foundation
import UIKit
import Kingfisher

class PhotoCollectionViewCell : UICollectionViewCell {

    @IBOutlet weak var photoImage : UIImageView!

    
    var photo: Photo!
}
